title: About me
date: 2015-04-26 10:18:00
---
#About Me

> You can get more informations about me at [www.daijiale.cn](http://www.daijiale.cn)

![](http://7xi6qz.com1.z0.glb.clouddn.com/djlblogpic20122013me.jpg)

![](http://7xi6qz.com1.z0.glb.clouddn.com/djlblogpicslrme.jpg)

> Glad to make friends with you !




