title: 下次人家问你怎么入门AndroidWear，你就甩这篇文章给ta
date: 2015-5-4 16:23:09
tags:

 - Android
 - AndroidWear
 - 智能可穿戴
 
categories:

 - 原创博文
 - Android开发笔记
 
---

#本文作者#

![](http://7xi6qz.com1.z0.glb.clouddn.com/djlblogpicslrme.jpg)

### [Jiale Dai](http://www.daijiale.cn) ###

成都 电子科技大学 本科生( 其实还没毕业，目前大三 ）

从14年开始一直专研于AndroidWear开发

百度 MBU RD Intern

百度 [DuWear](http://duwear.baidu.com) 团队成员

>**摘要：** 本文是Jiale Dai 在学习Google官方视频、开发者文档和实践项目之后整理出来的心得笔记，是以一个个人开发者的角度给大家带来一些侧面对Android Wear开发的看法，不同于一些传统的Android Wear技术开发教程，但是博主希望能通过自己对这些知识的整理和资源的收集，给读者带了一份详尽的、多角度的Android Wear指南。**无论你是程序员，设计师，产品经理，还是手表极客 ，Android Wear用户 or 小白，都能在这篇博文中找到你想要的Android Wear元素。**
> 博文会同时托管到Github上，欢迎更多承载着开源精神的有心人加入，分享你对Android Wear的见解。
<!-- more -->

#写在开头#
> **自己对AndroidWear的看法：**
> 
> Android Wear的目标就是：不接触手机的前提下，在你需要的时候，它把对你有用的信息呈现给你，扫一眼就够了。ta是
> 一种新的交互模型，有很多有利便捷新潮的交互体验是手机上无法实现的。将你自己置身于一个外部场景，在移动和忙碌中使用这项服务是什么样的体验，你就会发现ta的价值。

**下面我们来欣赏一段Android Wear的应用场景视频**（博主花了大精力才从鹅厂官网漏洞里抓取到的外链地址，**低调、低调**）：

<embed wmode="window" flashvars="vid=o0014kprxll&amp;tpid=28&amp;showend=1&amp;showcfg=1&amp;searchbar=1&amp;shownext=1&amp;list=2&amp;autoplay=1&amp;ptag=m_v_qq_com&amp;outhost=http%3A%2F%2Fv.qq.com%2Fpage%2Fo%2Fl%2Fl%2Fo0014kprxll.html&amp;refer=http%3A%2F%2Fm.v.qq.com%2Fpage%2Fo%2Fl%2Fl%2Fo0014kprxll.html%3Ffrom%3Dtimeline%26isappinstalled%3D0&amp;openbc=0&amp;title=%E8%B0%B7%E6%AD%8CAndroid%20Wear%E6%B7%B1%E5%BA%A6%E8%A7%A3%E6%9E%90" src="http://imgcache.qq.com/tencentvideo_v1/player/TencentPlayer.swf?max_age=86400&amp;v=20140714" quality="high" name="tenvideo_flash_player_1431178166025" id="tenvideo_flash_player_1431178166025" bgcolor="#000000" width="650px" height="472px" align="middle" allowscriptaccess="always" allowfullscreen="true" type="application/x-shockwave-flash" pluginspage="http://get.adobe.com/cn/flashplayer/">


##  核心元素： ##

 - Google Now：用户可以和AndroidWear“说话”（语音交互）。
 - Notifications:一个卡片，一个提醒，实现你最想要的服务。具体分为stacks、 pages、 replies、三种性质。
 - WatchFace：表之所以称之为“表”。
 - Data Message：和手机的数据通信机制是重要的桥梁。

## 构建一个Wear Apps的基础（wear app能做到什么？）： ##

**基础API元素:**

 - Custom UI
 - Send Data
 - Control Sensors
 - Voice Actions


下面我会举**四个例子**来说明基于这几个基础元素（Android Wear API）可以实现什么样级别的**Wear App**：
 

### Gmail ###

![](http://7xi6qz.com1.z0.glb.clouddn.com/androidweargmail.PNG)

 - Gmail Base On
    - Notification Bundles
    - RemoteInput for Voice Response
 
大家应该不会陌生Gmail，下面来看看其在wear端的app特性：

1、首先ta有两种邮件提醒类型：

**单页通知卡片（如下图）**

![](http://7xi6qz.com1.z0.glb.clouddn.com/androidwearsinglecard.PNG)

**多页通知卡片（如下图）**

![](http://7xi6qz.com1.z0.glb.clouddn.com/androidwearmuticard.PNG)

2、你可以通过滑动卡片，进一步了解更多信息，而且伴随有 **“语音快速回复” “归档” “在手机端打开回复”**三种操作，这里我们重点谈一下**语音快速回复**这个**具有wear特性**的操作流程：

 - 
`Android Notification API` 会让你通过远程输入给reply行为做一个注释,而远程输入则会告诉AndroidWear，在执行这个行为之前，你要把文本输入的方式改为语音，因此当Gmail建立一个notification连接时，wear端会给reply行为附加一个远程输入，AndroidWear会看到这条远程输入，然后不会立即发送一个行为，会首先启动一个wear UI界面来收集语音回复信息，然后把转换好的文本变成意图，再发送意图到你的手机上，手机得到意图后，就可以在不触动手机UI的情况下发送/回复邮件了。

下面是关键代码实现过程：

**Add RemoteInput to Reply Action**

```
Action replyAction = new NotificationCompat.Action.Builder(
	R.drawble.ic_reply,getString(R.string.reply), 
	replyPendingIntent)
    addRemoteInput(
	  new RemoteInput.Builder(EXTRA_REPLY_TEXT)
		.setLabel(getString(R.string.replyLabel))
		.build()).build();
```

**Modify Activity to Use Reply Text**

```
Bundle results =
	RemoteInput.getResultsFromIntent(intent);
	if(results!=null){
	 String message = 
		results getString(EXTRA_REPLY_TEXT)
	}
```


3、最后我再来详细介绍下“多卡片重叠式信息提醒”的实现原理，视觉设计上采用的是复线收件箱的风格，ta不再把多条信息压缩到单一的卡片中，我们想做的是每封邮件都有自己的卡片。而这些卡片又放入一个可扩大的堆栈中，这一堆提醒卡片，也叫提醒卡片堆栈，也是notification API的新特性，不会把所有邮件提醒都只能通过一个提醒显示出来，而是按类划分，表明有所关联，ta们在可穿戴设备上组合成一个卡片丛，而用户也可以通过卡片丛去逐个浏览，以提取某一封邮件，并对其回复或者进行其他操作。而卡片丛 即：notification group也有一个分类键，通过设置这个键来控制丛内卡片顺序，并且可以从中标记一个卡片作为组群的整体摘要描述，具体实现代码如下：


```
Notification card1 = 
	new NotificationCompat.Builder(context)
		.setGroup(GROUP_KEY)
		.setSortKey("0")
		.build();

Notification card2 = 
	new NotificationCompat.Builder(context)
		.setGroup(GROUP_KEY)
		.setSortKey("1")
		.build();

Notification card3 = 
	new NotificationCompat.Builder(context)
		.setGroup(GROUP_KEY)
		.setSortKey("2")
		.build();

Notification summary = 
	new NotificationCompat.Builder(context)
		.setGroup(GROUP_KEY)
		.setGroupSummar;
		.build();
```

### Hangouts ###

![](http://7xi6qz.com1.z0.glb.clouddn.com/androidwearhangouts.PNG)


 - Hangouts Base On
    - Custom Wearable Actions
    - Notification Pages
    
1、环聊信息也会自动桥接到可穿戴设备上，在Gmail上面，我们想要的是语音回复，但是环聊的提醒则稍微有点不同，ta并没有回复行为，只是一个内容意图，只需要打开App就可以键入回复了，所以环聊可以很好的不依赖手机而直接在可穿戴设备上进行体验，而且，android wear的 `Notification API`会让你在手机和可穿戴设备上细化不同的操作设置，即手机行为只在手机显示。wear行为只在wear端显示，这就使得我们可以添加一个仅限可穿戴设备使用的回复行为，这一行为涵盖了一个远程输入，却无需变动手机行为。

2、环聊也增加了新的提醒特征：近期会话历史记录。因为在语音回复之前，多出现一些聊天记录总是好的，为了实现这个效果，我们在wear设备扩充器中采用了添加页面的办法：它可以让你为主要提醒内容增加额外的页面，我们把聊天记录放入一个次级大的文本式提醒，然后把它加入到主要提醒中的第二页，并且手机端的提醒体验同时保持不变。关键代码实现如下：

```
Notification chatHistory =
	new NotificationCompat.Builder()
		.setStyle(
			new NotificationCompat.BigTextStyle()
				.bigText(getChatHistory()))
		.build();

firstPageNotification.extend(
	new NotificationCompat.WearableExtender()
		.addPage(chatHistory)
		.build());

```


###  Google Camera ###

![](http://7xi6qz.com1.z0.glb.clouddn.com/androidwearcamera.PNG)

 - Google Camera Base On
    - Wearable DataApi 
	- Wearable MessageAPI
	- WatchActivity 

1、wear端的google camera为相机App增加了好玩有趣的特性：**通过手腕来按下快门**，和很多具有远程遥控的高级相机原理类似，你把手机架在三脚架上或者靠在墙上又或者让其他人帮你拿着，然后你通过按住腕表的一个按键来捕捉一个画面**（代替现在正在热卖而很多大男生却不好意思在大街上用的自拍杆，嘿嘿）**。

2、相比于前面提到的Gmail和环聊（ta们只是用了 `Notification API` 来对手机端的消息做一个整合），Google Camera是一个相对个性而又具有和手机交互的特点，而且对于wear来说，仅仅只需要将**快门**这个按键特殊处理就行，所以，在wear端，光快门按键就霸占整个屏幕这一点也是可以容忍的。

3、通过 `Google Play Service`(以后简称 `GMS`)，实现相机的wear端和手机端通信，在相机手机app准备好拍摄时，手机端端会设置好数据项（意味着它已经做好了接受远程快门信息的准备），这种数据项由手表中wear app内置的服务读取，而wear端则会显示出快门按钮，按住按钮，把信息发回手机来激活手机端的快门键，最后，如何预览你刚才拍到的照片呢？很简单：手机端会创建一张缩略图，然后作为数据项中的一个asset发送回手表端，然后做为wear端全屏来预览。
关键代码如下：

**Setting a DataItem**

```
PutDataMapRequest dataMapRequest =
	PutDataMapRequest.create(DATA_ITEM_NAME);
dataMapRequest.getDataMap().putBoolean(
	FIELD_READY,cameraReady);
Wearable.DataApi.putDataItem(
	mGoogleApiClient,
	dataMapRequest.asPutDataRequest()
);
```
**WearableListenerService**

```
public class CameraListennerService
	extends WearableListennerService{
	@Override
	public void onDataChanged(DataEventBuffer dataEvents){
		for(DataEvent dataEvent:dataEvents){
		    if(dataEvent.getType()== 	DataEvent.TYPE_CHANGED){
			DataMapItem mapDataItem = 
				DataMapItem.fromDataItem(
					dataEvent.getDataItem());
			if(mapDataItem.getDataItem().getBoolean(FIELD_CAMERA_READY,false)){
			postNotification();
		}else{
		stopActivity();	
	}
	)
  }
 }
}
```
**Sending an Asset**

```
PutDataMapRequest dataMapRequest =
	PutDataMapRequest.create(DATA_ITEM_NAME);
dataMapRequest.getDataMap().putBoolean(
	FIELD_READY,cameraReady);

//在DataItem数据项中插入一个判断
if(previewBitmap != null){
	dataMapRequest.getDataMap().putAsset(
	 FIELD_PREVIEW,preview);
	)
}

Wearable.DataApi.putDataItem(
	mGoogleApiClient,
	dataMapRequest.asPutDataRequest()
);
```
### Google Maps ###

![](http://7xi6qz.com1.z0.glb.clouddn.com/androidwearmaps.PNG)

- Google Maps Base On
  - Voice Actions 
  - Custom Display Intent Notifications

1、在Google Maps导航期间，我们想要在手腕上提示导航，这个应用场景在走路的时候尤其有用，因为你要一直拿着你的手机走在大马路上会非常奇怪且占用你的双手，如果把手机放在你的口袋，转而看一下手表的描述来获知导航信息无疑更为便捷和实用。

2、在wear端，google想实现对布局和导航呈现精细的把握，特地搭建了一款wear版本的google maps wear App，让个性抽取式卡片成为限于本地的提醒，通过修改google map手机app的数据项，增加了用于下一次操作的描述与图标以及用于解释导航状态的信息，同时wear端的google maps也增加了这样的数据项，每次变动发生后，ta都会读取新数据，然后更新wear的卡片，提取卡片时，wear app采用可穿戴扩充器的新显示意图特性，你可以指定一个活动来在提醒卡片中绘制内容，这样我们想在卡片上画什么都是可以的，而不是受限制于标准提醒样式。
关键实现代码：

**Custom Notification with Display Intent**

```
Intent displayIntent = 
	createUpdateIntent(data, maneuverBitmap);
displayIntent.setClass(
	this,NotificationDisplayActivity.class);

PendingIntent displayPendingIntent = PendingIntent.getActivity(
	this,0,displayIntent,
	PendingIntent.FLAG_CANCEL_CURRENT);

Notification notification = builder.extend(
	new NotificationCompat.WearableExtender()
		.setHintHideIcon(true)
		.setDisplayIntent(displayPendingIntent)
		.setBackground(background)
		.addPage(secondPage)
		.build();

```

3、google map通过语音指令来开启导航进程，为了实现这一点，可
wear端的google map app会联手意图过滤器（ `Intent`）来为导航声音指令服务，然后需要在 `AndroidManifest.xml`中声明如下：

```
<activity
	android:name=".StarNavigationActivity"
	android:theme="@style/TranslucentTheme">
	<intent-filter>
	 <action
		android:name="android.intent.action.VIEW"/>
		<category			android:name="android.intent.category.DEFAULT"/>
	    <data
			android:scheme="google.navigation"/>
	</intent-filter>
</activity>
```

声明之后，就会产生一个像这样的意图，可穿戴App接收到这个意图之后，就会给手机上的google map发送一条信息，信息包括目的地和导航模式，手机google map app接收到这条信息之后，然后开始导航到目的地，然后就可以出发了，具体通信代码如下:

**Sending a Message**

```
private void startNavigation(Intent intent){
	
	String uriString = intent.getDataString();
	
	mGoogleApiClient.blockingConnect(
		Constants.TIMEOUT_MS,
		TimeUnit.MILLISECONDS);

	DataMap dataMap = new DataMap();
	dataMap.putString(FIELD_URI,uriString）；

	Wearable.MessageApi.sendMessage(
	   mGoogleApiClient,
	   mOtherNodeId,
	   Constants.MESSAGE_PATH_START_NAVIGATION,
		dataMap.toByteArray()).await();
	googleApiClient.diconnect();
}

```

**Receiving a Message**

```
public void onMessageReceived(
	MessageEvent messageEvent){
	if(messageEvent.getPath().equals(
		MESSAGE_PATH_START_NAVIGATION)){
	  DataMap requestData =
			DataMap.fromByteArray(
				messageEvent.getData());
			String uriString =
				requestData.getString(FIELD_URI);
			Intent navIntent = new Intent(
				Intent.ACTION_VIEW,
				Uri.parse(uriString));
			startActivity(navIntent);
	}
}

```


# 搭建云驱动的Android Wear Apps #


![](http://7xi6qz.com1.z0.glb.clouddn.com/djlblog_androidwear_cloud.JPG)


如图：

 - 1、首先，我们需要一款云服务来作为App的后端来进行数据推送和数据处理。
 - 2、其次，移动App会配合这项服务发出一个提醒，而你会在wear设备上看到，而且该提醒也会发送到任何相连的AndroidWear设备上。
 - 3、接着，当然就是AndroidWear App本身了，ta的特效是搭建在移动手机App之内，这样一旦手机App发出一条可以在手机上看见的提醒，这条信息也发给了Android Wear设备，现在的API也能够传送这些提醒，比如说触发回复行为，那么，我们是怎么实现ta们的呢？`Android Studio`实际上把你所需要的一切都给你了，包括用于搭建后端服务的工具包，当然还有Android手机App，现在你还可获得扩展包来操作Android Wear，云后端可以用一款外露的API来搭建，Android Studio工具包可以让你在Java下来进行此类操作，为你处理精细的细节把握，你可以写一段云端代码，通过使用属性，ta能够暴露出运行在你android app中的API，这些属性告诉Android客户端这些代码都是到底在干什么的，比如在执行一种叫quotesApi(引用API）时，并提供一种称为getQuote（获得引用）的方式，ok，一旦你现在搭建好了云服务，借助工具包，事实上你就可以自动创建客户端数据库来进入了，接下来，你要做的当然是搭建你的App了，那如何从你的App进入API呢？其实，这个分类已经自动帮你加载下来了，并且放入Maven库中了，这样你就可以直接在你搭建好的Gradle文件夹下涵盖它们了。

 - 4、最后，我们如何把它拓展来用于Android Wear呢？ 其实很简单，跟google map中的例子一样，通过修改notification和卡片的代码，使用wear端的api，让消息提醒和前端信息视图同时展现在手机客户端和wear端，此时的**手机App**就**变成了wear连接云端**的**中间件**。


# 写给设计师们：如何把握Android Wear下App的设计原则？ #

> PS：自己在DuWear项目组除了做RD研发之外，也对设计比较感兴趣，记得研发表盘那段时期，经常和搭档（MUX-UE-大侯）一起交流wear端的设计理念和心得，这里分享一些给想进军wear端的设计师朋友们：


**首先我们需要知道的是：**

 - Android Wear可以在多种不同的设备上运行，甚至在方形或圆形屏幕上也能正常运行，ta的UI非常简单，而且显示的内容也做了优化以适应小屏幕。
 - Android Wear的核心UI会自动排列卡片的优先级，非常简单，它整合了像Google Now，安卓手机提醒（Notification）和关联性App等资源，从而可以直接在wear端运行，开发师可以创建可以在这种流中正确显示的卡片，在任何点上，我都可以朝左滑动来查看每个项的更多信息，朝右滑动则会移除卡片，
 - 我们也给里面加入了向谷歌说话的能力，用户只需说一句：OK Google来搜索网络寻求答案，也可以进行我们称之为行为（actions）的语音指令，开发师可以深入开发这些语音行为。意味着用户可以直接对你的软件说话。
 - 可穿戴设备提供了一套前所未有的设计理念，
这即是机会，也是挑战，所以相对其他诸如手机或平板之类的设备，要清楚明白地搞懂它们之间的不同之处非常重要。
Android Wear刚好在正确的时间提供了正确的信息，让人们同时与虚拟和现实世界有更好的联系，信息内容会尽可能自动显示在信息流中，对于早已习惯打开App和退出App的我们来讲，这种对于模块的变化是相当巨大的。
## 设计思路： ##
 - **Contextual：**Android Wear会注意到周围环境，而且十分智能，这些设备会让人与计算机设备的亲密关系全新升级，Android Wear不要求用户的关注与输入，相反它会注意到用户所处的环境与状态，然后在正确的时间体贴地提供正确的信息，Android Wear会让人感觉信息及时，提议中肯，无微不至。
 
 - **Glanceable：**这些App只需要一瞥的时间，不算是可穿戴设备处于我们的视线边缘，它们也可以整天使用，高效的App会用最小的嗡嗡声来提供更多的信息提醒，并在细碎的关联信息提醒上做进一步优化，从而在一整天的碎片时间里得以应用。
 
 - **Low Interaction：**快速思考，一针见血，迅捷即时，而且几乎不用与设备互动，在保证小屏幕传送信息优势的同时，Android Wear着重与简单的互动，仅仅在非常必要的时候来需要用户来输入。而且绝大多数输入都是简单的点触、滑动和语音指令，而一般输入所需要的精细操控也得以避免。Android Wear手势简单，操作便捷而迅速

 - **Suggest&Demand：**最后，这些体验都与建议和指令相关，Android Wear就像一位出色的个人助理，它了解你，知道你的喜好，只有在绝对必要的时候才会打扰你，而且它总是近在手边，随时准备为你回答或完成任务。Android Wear贴心、礼貌、有问必答，它把周围世界与用户巧妙联系起来的同时，又极其尊重你的注意力，把你的焦距汇到重点项目上。
 - **Break It Down：**这里所呈现的机会并不是想象中的那样——把智能手机的UI缩小一下就塞进来,相反，需要考虑的是在设计过程中出现的基础性的问题，遵循这些原则之后，要是用户在使用你的产品操作任务时，产品出问题了怎么办？
 
接下来，我们来看一些**出色的设计案例**：
 
 - **Stream Apps**
 
![](http://7xi6qz.com1.z0.glb.clouddn.com/androidwearstreamapps.PNG)
 
 如图，系统中众多App的展现体现在那些垂直的卡片流之中，让小小的屏幕可以为用户尽可能多得展现更多的Wear应用，也是用户界面的核心所在。

 - **Main Interface**
 
![](http://7xi6qz.com1.z0.glb.clouddn.com/androidwearcarddesigner.PNG)
![](http://7xi6qz.com1.z0.glb.clouddn.com/androidweargooglenowcard.PNG)

 如图，这里我们看到主屏幕流中有一些卡片，像这种卡片就会在特定时刻，需要它们该出现的时候才出现。就像 `Google Now`一样，这些卡片无需启动或打开，相反，ta们会基于所在地、走路或者奔跑等活动、实际时间、用户的兴趣爱好以及其他因素来运行，你可以指定某项内容在合适的时候出现，这些卡片与环境息息相关，要注意看这些内容十分简洁，而且布局十分清楚，这些布局也经过了优化，让人能通过**眼角一瞥就能一目了然**。这些卡片也会遵循我们低互动（Low Interaction）的原则，它们没有大量的目录和按钮，用户可以直接滑动屏幕来进入另一页获取更多资料，事实上，通过Android Wear用户界面你应该使用像**滑动和全屏挥动**这样的大手势，不要在一个屏幕上放置多个需要点击的小按钮。


  - 更多Android Wear出色案例和设计资源请参考下文中的：[更多系列教程]()


# Android Wear搭建更高级别的UI #
可穿戴设备的App是Android的标准App，但遵循的是小屏幕的设计理念，它们全屏运行，没有系统UI或状态条，它们的开发过程与安卓App类似，不过在UI的开发理念上却稍有不同，最重要的就是要记住你的界面不必苛求小点触屏或精准的拖拽，举个例子，在可穿戴系统UI中，你会注意到对滑动操作的频繁使用，还有滚动条的运用，它之所以能够流畅运行，是因为它并不需要把注意力花在要去触摸屏幕某个精准的点上，为了帮助大家，Google提供了一个[可穿戴设备App的UI库](http://developer.android.com/training/wearables/ui/index.html)，它提供了异常丰富的元素来用于UI的设计。


![](http://7xi6qz.com1.z0.glb.clouddn.com/androidweargradpagerview.PNG)

这里，我想重点讲一下 `GridViewPager(网格多面控件)` ,ta与主页流类似，大家可以用ta来设计界面，ta与多面控件相似，但是可以水平和垂直同时移动，第一步就是布局的规划，下面这几行代码就是你主行为所需要的全部内容：

**res/layout/pager_example.xml**

```
<?xml version = "1.0" encoding = "utf-8"?>
<android.support.wearable.views.GridViewPager
	xmlns:android = "http://schemas.android.com"
	android:id = "@+id/pager"
	android:layout_width = "match_parent"
	android:layout_height = "match_parent"
/> 

```

在这里，配置多面控件的目的是用于扩展至整个屏幕的，下一步，我们需要一个衔接器（`Adapter`）

**FragmentGridPagerAdapter**

```
int getRowCount()
int getColumnCount(int row)
Fragment getItem(int row , int column)

int getCurrentColumnForRow(
	int row,int currentColum)

```
而这几行代码则是在用户使用导航时为用户提供每张页面所呈现的内容，在这个例子中，我会从一个由片段支持的基本类来进行扩展，要创建一个运行的`Adapter`只需要这三个方法，前两种定义了内容行（`row`）与页的可用大小，注意 `column` 的数量取决与行参数`row`,原因就在于每行可能都有不同的列数量，它的特性就是其选项可以控制每行在页面哪个位置来放置，与固定好的网格布局相比，它给滚动条在平等滚动与垂直滚动间切换提供了可能，在这一布局中，为了实现这点，Google还想了一些办法，但结果看起来就是一个无缝对接，Google为什么要这么做？Google认为每行内容都是单独的存在，在主页流中，这些就成了提醒或Google Now卡片，用户要从一个行为页进入到目标页而进行上下滑动的操作时，如果有不同的项，那么用户在操作时就会迷惑，为了解决这个问题，上翻或下翻总会回到第一列，这个也是网格多面控件的默认模式，为了对此做出调整，你可以用另一种方式进行覆盖，这种方式称为：所想即所见（用户想了解某项信息时，该信息的页面就会呈现在当前页或下一页），它也会提供当前列的位置，为了返回固定的移动系统，你可以选择返回列，或许你还想保存该行上次浏览的那一列，以便下次选择改行时可以直接返回到那一列。最后，最重要的一点就是getItem了，这个就是你要在页面上呈现出片段的位置了，这里，你只需要返回到你的内容片段，然后剩下的事情就由多面控件来处理了。只要需要，内容片段可以长久存储，然后在合适的时候，要么删除，要么重新进入，在这种方式跟多面控件非常类似，只是加了一个垂直的维度而已。


![](http://7xi6qz.com1.z0.glb.clouddn.com/androidwearcontentPage.PNG)

为了帮助大家建立自己的页面内容，Google提供了卡片内容片段，它可以自动应用不同的风格,从而与系统卡片搭配一致，而你要做的只是提供内容就可以，这种内容片段也有许多附加特性，首先，如果你有超过一页的内容，它就会显示滚动条让你拖动到正确的位置，你也可以让它作为一个单独页面开始，这样就可以通过触按来放大到全屏了，在这个案例中，内容溢出会自动得到处理，在你代码样本和文档中会找到更多细节的，还有一些事情要记住：每个页面尽量只放一个单独的行为，如果可能的话，整张卡片应该做成一个触按目标，而需要运行的行为则应该清楚明白，现在，剩下需要做的就是把这些东西整合起来，转接类会处理所有内容片段操作,所以需要给片段管理来一个参数，把转接代码加入到页面代码中就行了。

**SampleActivity.java**

```

public void onCreate(Bundle savedInstanceState){
	 setContentView(R.layout.pager_example);
	 mPager = findViewById(R.id.pager);
	 mAdapter = new ExampleGridPagerAdapter(getFragmentManager());
	 mPager.setAdapter(mAdapter);	
	}

```


# Android Wear的提醒（Notification）新特性 #

我们来看看wear设备提醒的三个新方面吧：
 
 - 新的显示选项
 - 新的提醒行为
 - 高级自定义设置



这里有博主自己曾经写过的一个运行在Android手机上的Demo，用来展示Wear端的Notification新特性:[在Github上获取](https://github.com/AndroidWearDemo/AndroidWearNotification)

# Android Wear下的全屏App设计理念 #

为Android Wear设计APP的许多技术因素，你们会觉得非常熟悉，因为它们跟普通的Android APP运行原理是一样的，不过呢，我今天主要讲的是**两大不同点**：

## 让用户如何退出APP ##
 
在手机或平板上，用户会使用返回或主页键来推出APP，但这些按钮在Android Wear设备上都不会出现，相反，在wear app上，用户离开你的APP会有如下两种办法：**一种是把页面朝左滑动至边缘退出，另一种是长按APP退出**：

   ### 滑动退出： ###

通过Android Wear我们引入了一种新的窗口属性：
        
```
< style name ="AppTheme" parent = "Theme.DeviceDefault" >
	< item name = "android.windowSwipeToDismiss">true< /item >
< /style >
```

**即窗口滑动属性**，这种窗口属性可以运用在你具体的活动主题中，一旦窗口滑动退出属性设置为true，那么活动一旦从左滑动至右，它就会退出，这种滑动退出运行方式跟多面控件运行方式类似，如果活动中的内容本身就可以滚动，那么窗口就不会退出，除非用户滚动到该内容边缘后再次滑动，它可以让你创建一些非常出色、类似信息流的体验，这些体验也可以通过滑动来退出。所有的Android Wear APP要么使用设备默认主题，要么使用一个继承默认设备的主题，这样可以确保不同的主题风格都会在你的APP上正常运行，从而让它们在你的wear设备上看起来非常好，

**You get it by default**

```
<activity
	android:name=".ControlRobotsActivity"
	android:theme="Theme.DeviceDefault"
/>

``` 
当然，我们知道，有些APP没办法使用滑动退出的功能，比如，无限移动的地图应用时永远没有边缘的，如果你不想使用滑动手势，那么你可以通过吧滑动的退出属性设置为false，来在你的主题中禁用ta。对于无法通过滑动来退出的APP。我们可以使用第二个属性：即**长按退出功能。**
    
### 长按退出 ###
这就相当于是一个退出按钮的行为了，为了让用户知道你的APP可以长按退出，在APP首次运行时，你要给用户一个长按退出的提示。打开我们的wear设备，你会发现在屏幕任何地方出现长按行为，都会在APP上出现一个退出按钮。再按下那个按钮来退出活动，用户则会回到主页，为了让你的APP退出变得尽量容易，Google做了一个可以在大多数UI上运行的View,它叫退出覆盖视图（dismiss overlay view）
     
**activity_control_robots.xml**
     
```
<android.support.wearable.view.DismissOverlayView
	android:id="@+id/dismiss_overlay"
	android:layout_height="match_parent"
      android:layout_width＝"match_parent"
     />    

```
为了把它集成到你的APP中，首先要把它添加进你的XML活动层中，确保它**增加的位置一定是在其他布局之上的**你还要确保该视图的尺寸能够覆盖整个屏幕，把它高度和宽度设置成与父框架相匹配，这样它就能够确保全屏，而且处于最顶层了，现在我们来看看java类里面怎么写：

**ControlRobotsActivity.java**

```
public void onCreate(Bundle savedState){
	super.onCreate(savedState);
	setContentView(R.layout.activity_control_robots);
	
	mDismissOverlay = (DismissOverlayView)findViewById(R.id.dismiss_overlay);
	mDismissOverlay.setIntroText(R.string.long_press_intro);
	mDismissOverlay.showIntroIfNecessary();
    
     mDetector = new GestureDetector(this,new SimpleOnGestureListener(){
       public void onLongPress(MotionEvent ev){
       	mDismissOverlay.show();
       }
     
     });
    }
    
    
...


@Override
public boolean onTouchEvent(MotionEvent ev){
	return mDetector.onTouchEvent(ev) | | super.onTouchEvent(ev);	
}    
```

在它的`onCreate`中把退出层从你的布局层中拉出来，然后设置为内省文本，这个文本会在第一次运行活动时显示出来，而且会显示在APP其他内容之上，用来告诉用户可以通过长按来返回主页，然后，使用`showIntroIfNecessary`(必要时显示内省文本)，它会，也只会在第一次运行该APP时显示这个内省层，，接下来，如果用户长按了你的app，我们就需要让它激活，使用`GestureDectector`(手势检测器）和`SimpleOnGestureListener`（简易手势接收器）,使用这些框架类会确保所有app感应到手势的时长，在你长按返回时，会激活布局层显示退出行为，会显示一个退出按钮，如果用户点击了该按钮，你的活动就会被结束，但如果你没有点击该按钮，那么这个退出层就会自行隐藏，等着下次出现的命令，最后，还是在你的活动中覆盖一层 `onTouchEvent` (触控事件)，然后让`reveiveTouchEvents` (接受触控事件)连通到`GestureDectector`（手势检测器）,如果 `GestureDetector` 返回为true，你也真的返回主页了，而且不用触动 `onTouchEvent` 方式的正常活动,相反如果为false，那就可以继续使用正常活动的触控。

## 如何设计和运用你的APP，让ta看起来在圆形屏幕上很不错。 ##

 
# Android Wear 数据层API DevBytes #


持续更新中

# Android Wear 下的表盘（WatchFace）设计 #

持续更新中

# Android Wear表盘（WatchFace）开发 #
不得不承认，Google在表盘方面上还是很鼓励第三方开发者去自由创作的，有别于
[Apple Watch不允许接入第三方watch face应用](http://www.leikeji.com/article?2264)的做法。



# Android Wear更多系列教程： #

> 博主认为，目前天朝的可穿戴社区仍处于起步阶段，很多资源还不丰富，但是天朝程序猿的力量是强大的，相信随着更多wear developers的加入，可穿戴的社区会愈来愈壮大，最后仅以自己微薄之力，为Android Wear开源做出一点贡献，希望能帮助到更多的人。


下面汇总了目前国内比较好的一些Android Wear资源，请参考：

 - 开发类
  - [Android Wear Google官方教程（请翻墙，或者自己搜镜像）](http://developer.android.com/wear/index.html)
  - [Android Wear Google官方教程 `穿戴猫`汉化版本](http://dev.seacat.cn/index.html)
  - [Android Wear `穿戴猫`社区原创基础教程](http://bbs.seacat.cn/forum-106-1.html)
  - [benhero博客_Android Wear开发学习指南](http://www.cnblogs.com/benhero/p/4273800.html)
 - 设计类 
  - [Google 官方Android Wear设计教程（需要翻墙）](http://developer.android.com/design/wear/index.html) 
  - [Google 官方Android Wear表盘（WatchFace）设计教程（需要翻墙）](http://developer.android.com/design/wear/watchfaces.html)
  - [Google Android Wear 设计规范学习心得 ](http://note.youdao.com/share/?id=1a46e80cb5ea07b5c755d38b65ff9576&type=note)
  - [TencentOS智能手表表盘设计大赛](http://tencentos.ui.cn/)
  - [FaceRepo for WatchMaker/Facer表盘引擎收集网站](http://facerepo.com/app/)


# Google Play 上热门的Android Wear应用 #

> 博主收集了一些谷歌市场上比较热门的Android Wear应用，期待更多朋友的补充和意见，大家可以下载下来体验，翻不了墙的同学请默哀。

 - [22款很棒的Android Wear表盘应用](http://note.youdao.com/share/?id=ee853cdb7e4283bade26e485d6ca2c60&type=note)

 - [31款很棒的Android Wear应用](http://note.youdao.com/share/?id=0037856aa8e5e0c2476b9a9f4950baa5&type=note)

 - [Magic WatchFace神奇表盘应用](http://www.magicwatchface.com/zh_cn)


# 热门的可穿戴技术社区 #

> 收录了一些博主目前暂时所知的"可穿戴技术社区"，期待更多朋友的补充和意见！
 
 - 国内：
  - [穿戴猫](http://www.seacat.cn/)
  - [DuWear](http://duwear.baidu.com/)
  - [Ticwear](http://ticwear.com/)
  - [Tencent OS for Watch](http://watch.tos.cn/)
  - [手表控](http://www.watchkong.com/forum/forum.php)
  - [雷科技](http://www.leikeji.com/)
  - [可穿戴设备](http://wearable.hqbpc.com/)
  - [控哪儿网](http://www.kongnar.com/)
  - [出行精灵](http://www.mapelf.com/)
 - 国外：
  - 由于天朝特殊原因，等以后更新。


#Android Wear相关产品宣传视频#

 - [Google：wear what you want](http://www.cgangs.com/article/3467?source=sinaweibo)
 - [Moto360创意广告](http://www.tudou.com/programs/view/jKv0PSWHdCY/)
 - [Moto360中文应用场景广告](http://baidu.fun.tv/watch/2542550633994583670.html)
 - [华为AndroidWear智能手表官方宣传片1](http://my.tv.sohu.com/us/243481507/79477160.shtml)
 - [华为AndroidWear智能手表官方宣传片2](http://my.tv.sohu.com/us/5747262/78630855.shtml)


#加入我们#




**转载**请注明**出处+原文链接+原文作者**，侵权必究，谢谢！