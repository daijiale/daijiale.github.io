title: 【Node.js-持续更新】Node.js学习开发笔记
date: 2015-7-6 19:21:11
tags:

 - Javascript
 - Node.js

categories:

 - 原创博文
 - Web开发笔记

---


# 前言 #

> 第一次接触Node.js是大二在四川长虹实习期间，距现在已经1年多了，在自己的一些项目中有用到，积累了一些经验，但是想更加系统的学习一下这门技术（主要这两年发展的太火了。。），同时也想把一些开发过程中的问题和案例分享出来， 特为此撰写一篇博客笔记...
<!--more-->


# 学习篇 #

## Node.js相比于PHP、Java、Python的优势

 - [Node.js和Python优势对比](http://www.zhihu.com/question/20961574)

 - [Node.js和PHP的优势对比](http://note.youdao.com/share/?id=a83b62577821d670122f8d08a67d8fd4&type=note)
  - [Node.js和PHP的优势对比2](http://www.admin10000.com/document/6536.html)
 

## Node.js的版本 

 - 偶数位为稳定版本（-0.6x   -0.8x  -0.10.x）
 - 奇数为非稳定版本（-0.7x   -0.9x  -0.11.x）

# 开发篇 #



