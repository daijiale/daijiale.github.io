title: cool-sites
date: 2016-07-22 13:02:49
---

# 开发

## SDK+云服务

 - [Discuz论坛搭建平台](http://open.discuz.net/?ac=index)
 - [语音开放平台](http://open.voicecloud.cn/download.php)
 - [Face++人脸识别开放平台](http://www.faceplusplus.com.cn/)
 - [Ping++移动支付接口](https://pingxx.com/?features)
 - [ThinkPHP框架](http://www.thinkphp.cn/)
 - [高德LBS开发平台](http://developer.amap.com/)
 - [环信IM开放平台](http://www.easemob.com/hx/index.html) 
 - [融云IM开放平台](http://www.rongcloud.cn/)
 - [LeanCloud移动开发云服务平台](https://leancloud.cn/)
 - [APICloud移动开发云服务平台](http://www.apicloud.com/)
 - [AppCan移动开发云服务平台](http://www.appcan.cn/)
 - [Mob短信验证开发平台](http://mob.com/#/index)
 - [AmazonCloud](https://www.amazon.cn/clouddrive?_encoding=UTF8&mgh=1&ref_=nav_Photos_Files&sf=1)
 - [DaoCloud企业级容器云平台](https://www.daocloud.io/)
 - [图谱科技-图像识别开发平台](https://open.tuputech.com/home)
 - [趣拍-短视频开发平台](http://www.qupai.me/sdk.html)
 - [阿里百川-无线开发平台](http://baichuan.taobao.com/portal/docIndex.htm?spm=a3c0d.7662652.1.4.f1ePDx)
 - [多说-评论第三方开发系统](http://duoshuo.com/)
 - [看云kancloud-API文档在线编辑工具](http://www.kancloud.cn/)

## 大牛Github/Blog

- [Leancloud_demo_github](https://github.com/leancloud/leancloud-demos#javsscript)
- [阮一峰的网络日志](http://www.ruanyifeng.com/blog/)
- [Laruence的博客](http://www.laruence.com/)
- [zouxy09_CSDN专栏](http://blog.csdn.net/zouxy09/article/list/3)
- [囧克斯的Blog](http://jiongks.name/about/)


# Mac相关资源

- [Awesome Mac](https://github.com/jaywcjlove/awesome-mac)