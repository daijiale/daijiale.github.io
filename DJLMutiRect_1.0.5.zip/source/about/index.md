title: 关于我
date: 2015-04-26 10:18:00
---

#关于我

- You can get more informations about me at [LinkedIn](http://www.linkedin.com/in/jiale-dai-baab98109?trk=hp-identity-name)






