title: 【数据库-持续更新】MySQL学习笔记
date: 2015-05-19 15:23:01
tags:

 - 数据库

 
categories:

 - 原创博文
 - Web开发笔记
 
---


>PS：来自一些参考书和视频的MySQL学习笔记，在这里集中整理一下，持续更新中。

<!--more-->


# 概述

- MySQL基础
- 安装MySQL
- 配置MySQL
- 使用MySQL


MySQL基础：

- 最早由瑞典MySQL AB公司开发，目前属于Oracle公司。

- MySQL是一个开源的关系型数据库管理系统。

- MySQL分为企业版（付费）和社区版（免费）